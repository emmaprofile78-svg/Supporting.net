import { TrendingUp, Coins, Globe, PieChart } from "lucide-react";

interface Service {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const services: Service[] = [
  {
    icon: <TrendingUp className="w-8 h-8" />,
    title: "Stocks",
    description: "Access global equity markets with real-time data, advanced analytics, and personalized portfolio management for individual and institutional investors.",
  },
  {
    icon: <Coins className="w-8 h-8" />,
    title: "Crypto",
    description: "Trade digital assets with institutional-grade security, low fees, and access to major cryptocurrencies and emerging blockchain opportunities.",
  },
  {
    icon: <Globe className="w-8 h-8" />,
    title: "Forex",
    description: "Navigate foreign exchange markets with competitive spreads, leverage options, and expert market insights for currency trading strategies.",
  },
  {
    icon: <PieChart className="w-8 h-8" />,
    title: "ETFs",
    description: "Build diversified portfolios with exchange-traded funds offering broad market exposure, low costs, and transparent fee structures.",
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-24 bg-background border-y border-border">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              Our Offerings
            </span>
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Investment Services
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl">
            Comprehensive financial solutions tailored to your investment goals and risk profile.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="group card-luxury hover:border-accent transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 cursor-pointer"
            >
              {/* Icon container with Art Deco styling */}
              <div className="mb-6 relative inline-block">
                <div className="absolute -inset-3 border border-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="relative w-16 h-16 flex items-center justify-center bg-card border border-border text-accent group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                  {service.icon}
                </div>
              </div>

              {/* Content */}
              <h3 className="font-serif text-2xl font-bold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="font-sans text-sm text-muted-foreground leading-relaxed">
                {service.description}
              </p>

              {/* Decorative bottom accent */}
              <div className="mt-6 pt-4 border-t border-border opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-8 h-px bg-accent" />
              </div>
            </div>
          ))}
        </div>

        {/* Decorative elements */}
        <div className="mt-16 pt-16 border-t border-border">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <div className="font-serif text-3xl font-bold text-accent">24/7</div>
              <p className="font-sans text-sm text-muted-foreground">
                Round-the-clock market access and customer support
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-serif text-3xl font-bold text-accent">99.9%</div>
              <p className="font-sans text-sm text-muted-foreground">
                Platform uptime and reliability guarantee
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-serif text-3xl font-bold text-accent">0.01%</div>
              <p className="font-sans text-sm text-muted-foreground">
                Competitive commission rates for active traders
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
