import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface HeroSectionProps {
  onGetStarted?: () => void;
  onLearnMore?: () => void;
}

export default function HeroSection({ onGetStarted, onLearnMore }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Top-left corner accent */}
        <div className="absolute top-0 left-0 w-96 h-96 border-l-2 border-t-2 border-accent opacity-10" />
        {/* Bottom-right corner accent */}
        <div className="absolute bottom-0 right-0 w-96 h-96 border-r-2 border-b-2 border-accent opacity-10" />
        {/* Center geometric accent */}
        <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-accent opacity-20 rotate-45" />
        <div className="absolute top-2/3 left-1/4 w-2 h-2 bg-accent opacity-20 rotate-45" />
      </div>

      <div className="container relative z-10 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-up">
            {/* Decorative line above headline */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-px bg-accent" />
              <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
                Premium Investment Solutions
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight">
              Elevate Your
              <span className="block text-accent">Wealth</span>
            </h1>

            {/* Subtext */}
            <p className="font-sans text-lg text-muted-foreground leading-relaxed max-w-lg">
              Experience institutional-grade investment management with the sophistication of a modern financial powerhouse. Secure your financial future with our comprehensive suite of investment services.
            </p>

            {/* Decorative divider */}
            <div className="w-16 h-1 bg-gradient-to-r from-accent to-transparent" />

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={onGetStarted}
                className="btn-luxury-primary group"
              >
                Get Started
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                onClick={onLearnMore}
                className="btn-luxury-secondary"
              >
                Learn More
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex items-center gap-8 pt-8 border-t border-border">
              <div>
                <div className="font-serif text-2xl font-bold text-accent">$2.5B+</div>
                <div className="font-sans text-sm text-muted-foreground">Assets Under Management</div>
              </div>
              <div>
                <div className="font-serif text-2xl font-bold text-accent">50K+</div>
                <div className="font-sans text-sm text-muted-foreground">Active Clients</div>
              </div>
              <div>
                <div className="font-serif text-2xl font-bold text-accent">25+</div>
                <div className="font-sans text-sm text-muted-foreground">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Right Visual Element */}
          <div className="hidden md:flex items-center justify-center animate-fade-in">
            <div className="relative w-full aspect-square max-w-md">
              {/* Outer frame */}
              <div className="absolute inset-0 border-2 border-accent" />
              <div className="absolute -top-4 -left-4 w-8 h-8 border-t-2 border-l-2 border-accent" />
              <div className="absolute -bottom-4 -right-4 w-8 h-8 border-b-2 border-r-2 border-accent" />

              {/* Inner content */}
              <div className="absolute inset-8 border border-border flex flex-col items-center justify-center gap-6 p-8">
                {/* Decorative chart visualization */}
                <div className="w-full space-y-4">
                  {[0.7, 0.85, 0.6, 0.9, 0.75].map((height, idx) => (
                    <div key={idx} className="flex items-end gap-2">
                      <div
                        className="flex-1 bg-gradient-to-t from-accent to-accent/50"
                        style={{ height: `${height * 80}px` }}
                      />
                    </div>
                  ))}
                </div>

                {/* Text overlay */}
                <div className="text-center space-y-2">
                  <div className="font-serif text-2xl font-bold text-accent">+24.5%</div>
                  <div className="font-sans text-xs text-muted-foreground uppercase tracking-wider">
                    YTD Performance
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom decorative line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent to-transparent" />
    </section>
  );
}
