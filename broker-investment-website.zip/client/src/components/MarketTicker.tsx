import { useEffect, useState } from "react";
import { TrendingDown, TrendingUp } from "lucide-react";

interface TickerItem {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
}

const generateMockData = (): TickerItem[] => {
  return [
    { symbol: "AAPL", price: 189.45, change: 2.15, changePercent: 1.15 },
    { symbol: "GOOGL", price: 142.80, change: -1.20, changePercent: -0.84 },
    { symbol: "MSFT", price: 416.23, change: 5.47, changePercent: 1.33 },
    { symbol: "TSLA", price: 245.60, change: -3.40, changePercent: -1.36 },
    { symbol: "BTC", price: 67420.00, change: 1250.00, changePercent: 1.89 },
    { symbol: "ETH", price: 3580.50, change: -85.50, changePercent: -2.33 },
    { symbol: "NVDA", price: 875.30, change: 12.45, changePercent: 1.44 },
    { symbol: "AMD", price: 168.90, change: -2.10, changePercent: -1.23 },
    { symbol: "SPY", price: 549.80, change: 3.20, changePercent: 0.59 },
    { symbol: "QQQ", price: 480.45, change: 6.75, changePercent: 1.42 },
  ];
};

export default function MarketTicker() {
  const [data, setData] = useState<TickerItem[]>(generateMockData());

  useEffect(() => {
    // Simulate price updates every 3 seconds
    const interval = setInterval(() => {
      setData((prevData) =>
        prevData.map((item) => {
          const changeAmount = (Math.random() - 0.5) * 10;
          const newPrice = Math.max(item.price + changeAmount, 1);
          return {
            ...item,
            price: newPrice,
            change: changeAmount,
            changePercent: (changeAmount / item.price) * 100,
          };
        })
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Duplicate data for seamless scrolling
  const tickerItems = [...data, ...data];

  return (
    <div className="w-full bg-card border-y border-border overflow-hidden">
      <div className="flex animate-ticker-scroll hover:pause">
        {tickerItems.map((item, idx) => (
          <div
            key={`${item.symbol}-${idx}`}
            className="flex items-center gap-4 px-8 py-3 min-w-max border-r border-border last:border-r-0"
          >
            <span className="font-serif font-bold text-accent text-sm uppercase tracking-wider">
              {item.symbol}
            </span>
            <span className="font-sans font-semibold text-foreground">
              ${item.price.toFixed(2)}
            </span>
            <div
              className={`flex items-center gap-1 text-sm font-medium ${
                item.change >= 0 ? "text-green-400" : "text-red-400"
              }`}
            >
              {item.change >= 0 ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
              <span>
                {item.change >= 0 ? "+" : ""}
                {item.change.toFixed(2)} ({item.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* CSS for ticker animation */}
      <style>{`
        @keyframes ticker-scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-ticker-scroll {
          animation: ticker-scroll 60s linear infinite;
        }

        .animate-ticker-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
}
