import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-background border-t border-border">
      {/* Decorative top line */}
      <div className="h-px bg-gradient-to-r from-transparent via-accent to-transparent" />

      <div className="container py-16">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <Link href="/">
              <a className="flex items-center gap-2 group">
                <div className="w-10 h-10 border-2 border-accent flex items-center justify-center">
                  <span className="font-serif text-xl font-bold text-accent">Ⓒ</span>
                </div>
                <span className="font-serif text-lg font-bold text-foreground">
                  Apex Capital
                </span>
              </a>
            </Link>
            <p className="font-sans text-sm text-muted-foreground">
              Sophisticated investment solutions for the discerning investor.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-serif text-sm font-bold text-foreground uppercase tracking-wider">
              Navigation
            </h4>
            <ul className="space-y-2">
              {[
                { label: "Home", href: "/" },
                { label: "Services", href: "#services" },
                { label: "Markets", href: "#markets" },
                { label: "About", href: "#about" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="font-sans text-sm text-muted-foreground hover:text-accent transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="font-serif text-sm font-bold text-foreground uppercase tracking-wider">
              Services
            </h4>
            <ul className="space-y-2">
              {["Stocks", "Crypto", "Forex", "ETFs"].map((service) => (
                <li key={service}>
                  <a
                    href="#services"
                    className="font-sans text-sm text-muted-foreground hover:text-accent transition-colors"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-serif text-sm font-bold text-foreground uppercase tracking-wider">
              Legal
            </h4>
            <ul className="space-y-2">
              {["Privacy Policy", "Terms of Service", "Risk Disclosure", "Contact"].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="font-sans text-sm text-muted-foreground hover:text-accent transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent my-12" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="font-sans text-sm text-muted-foreground">
            © {currentYear} Apex Capital. All rights reserved.
          </p>

          {/* Social Links */}
          <div className="flex gap-6">
            {["Twitter", "LinkedIn", "Facebook", "Instagram"].map((social) => (
              <a
                key={social}
                href="#"
                className="font-sans text-sm text-muted-foreground hover:text-accent transition-colors"
              >
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom decorative line */}
      <div className="h-px bg-gradient-to-r from-transparent via-accent to-transparent" />
    </footer>
  );
}
