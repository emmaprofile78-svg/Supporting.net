import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Send } from "lucide-react";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.name.trim()) {
      toast.error("Please enter your name");
      return;
    }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return;
    }
    if (!formData.message.trim()) {
      toast.error("Please enter a message");
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate form submission
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Show success message
      toast.success("Message sent successfully! We'll be in touch shortly.");

      // Reset form
      setFormData({
        name: "",
        email: "",
        message: "",
      });
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-card border-t border-border">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              Get In Touch
            </span>
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Contact / Get Started
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl">
            Ready to elevate your investment strategy? Connect with our team today for a personalized consultation.
          </p>
        </div>

        {/* Form Container */}
        <div className="max-w-2xl mx-auto">
          <div className="card-luxury">
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-8 h-8 border-t-2 border-l-2 border-accent" />
            <div className="absolute -bottom-4 -right-4 w-8 h-8 border-b-2 border-r-2 border-accent" />

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Field */}
              <div className="space-y-2">
                <label htmlFor="name" className="font-sans text-sm font-semibold text-foreground">
                  Full Name
                </label>
                <Input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.name}
                  onChange={handleChange}
                  className="bg-background border-border focus:border-accent focus:ring-accent"
                  disabled={isSubmitting}
                />
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <label htmlFor="email" className="font-sans text-sm font-semibold text-foreground">
                  Email Address
                </label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Enter your email address"
                  value={formData.email}
                  onChange={handleChange}
                  className="bg-background border-border focus:border-accent focus:ring-accent"
                  disabled={isSubmitting}
                />
              </div>

              {/* Message Field */}
              <div className="space-y-2">
                <label htmlFor="message" className="font-sans text-sm font-semibold text-foreground">
                  Message
                </label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder="Tell us about your investment goals and how we can help..."
                  value={formData.message}
                  onChange={handleChange}
                  className="bg-background border-border focus:border-accent focus:ring-accent min-h-32 resize-none"
                  disabled={isSubmitting}
                />
              </div>

              {/* Decorative divider */}
              <div className="h-px bg-gradient-to-r from-transparent via-accent to-transparent" />

              {/* Submit Button */}
              <Button
                type="submit"
                className="btn-luxury-primary w-full group"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <span className="animate-spin mr-2">⏳</span>
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <Send className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>

              {/* Trust indicators */}
              <div className="pt-4 border-t border-border text-center">
                <p className="font-sans text-xs text-muted-foreground">
                  We respect your privacy. Your information is secure and will never be shared.
                </p>
              </div>
            </form>
          </div>

          {/* Contact Info Cards */}
          <div className="mt-16 grid md:grid-cols-3 gap-6">
            <div className="card-luxury text-center">
              <div className="font-serif text-2xl font-bold text-accent mb-2">📧</div>
              <h4 className="font-serif text-lg font-bold text-foreground mb-1">Email</h4>
              <p className="font-sans text-sm text-muted-foreground">
                hello@apexcapital.com
              </p>
            </div>
            <div className="card-luxury text-center">
              <div className="font-serif text-2xl font-bold text-accent mb-2">📞</div>
              <h4 className="font-serif text-lg font-bold text-foreground mb-1">Phone</h4>
              <p className="font-sans text-sm text-muted-foreground">
                +1 (555) 123-4567
              </p>
            </div>
            <div className="card-luxury text-center">
              <div className="font-serif text-2xl font-bold text-accent mb-2">🕐</div>
              <h4 className="font-serif text-lg font-bold text-foreground mb-1">Hours</h4>
              <p className="font-sans text-sm text-muted-foreground">
                24/7 Support Available
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
