import { Award, Users, Globe, Zap } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              About Us
            </span>
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Redefining Wealth Management
          </h2>
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Column - Mission & Vision */}
          <div className="space-y-8">
            <div>
              <h3 className="font-serif text-3xl font-bold text-foreground mb-4">Our Mission</h3>
              <p className="font-sans text-lg text-muted-foreground leading-relaxed">
                Apex Capital exists to democratize access to institutional-grade investment management. We believe that sophisticated financial tools and expert guidance should be available to everyone, regardless of portfolio size.
              </p>
            </div>

            <div className="w-16 h-1 bg-gradient-to-r from-accent to-transparent" />

            <div>
              <h3 className="font-serif text-3xl font-bold text-foreground mb-4">Our Vision</h3>
              <p className="font-sans text-lg text-muted-foreground leading-relaxed">
                To become the world's most trusted investment platform, where innovation meets integrity, and where every client achieves their financial aspirations through personalized, data-driven strategies.
              </p>
            </div>

            <div className="w-16 h-1 bg-gradient-to-r from-accent to-transparent" />

            <div>
              <h3 className="font-serif text-3xl font-bold text-foreground mb-4">Our Values</h3>
              <ul className="space-y-3 font-sans text-muted-foreground">
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">•</span>
                  <span><strong>Integrity:</strong> Transparent, ethical practices in all dealings</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">•</span>
                  <span><strong>Excellence:</strong> Relentless pursuit of superior outcomes</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">•</span>
                  <span><strong>Innovation:</strong> Cutting-edge technology and strategies</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">•</span>
                  <span><strong>Partnership:</strong> Collaborative relationships with clients</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Right Column - Visual Stats */}
          <div className="space-y-6">
            {/* Decorative frame */}
            <div className="relative">
              <div className="absolute -inset-4 border-2 border-accent opacity-20" />
              <div className="absolute -top-6 -right-6 w-12 h-12 border-t-2 border-r-2 border-accent" />
              <div className="absolute -bottom-6 -left-6 w-12 h-12 border-b-2 border-l-2 border-accent" />

              <div className="relative bg-card border border-border p-8 space-y-8">
                {/* Stat 1 */}
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-5xl font-bold text-accent">25</span>
                    <span className="font-sans text-sm text-muted-foreground">Years</span>
                  </div>
                  <p className="font-sans text-sm text-muted-foreground">
                    Of proven excellence in wealth management
                  </p>
                </div>

                <div className="h-px bg-gradient-to-r from-accent to-transparent" />

                {/* Stat 2 */}
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-5xl font-bold text-accent">$2.5B</span>
                    <span className="font-sans text-sm text-muted-foreground">AUM</span>
                  </div>
                  <p className="font-sans text-sm text-muted-foreground">
                    Assets under management across all strategies
                  </p>
                </div>

                <div className="h-px bg-gradient-to-r from-accent to-transparent" />

                {/* Stat 3 */}
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-5xl font-bold text-accent">50K</span>
                    <span className="font-sans text-sm text-muted-foreground">Clients</span>
                  </div>
                  <p className="font-sans text-sm text-muted-foreground">
                    Active investors trusting our platform
                  </p>
                </div>

                <div className="h-px bg-gradient-to-r from-accent to-transparent" />

                {/* Stat 4 */}
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="font-serif text-5xl font-bold text-accent">+24.5%</span>
                    <span className="font-sans text-sm text-muted-foreground">Avg Return</span>
                  </div>
                  <p className="font-sans text-sm text-muted-foreground">
                    Average annual performance (2023-2024)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Team Highlights */}
        <div className="border-t border-border pt-16">
          <h3 className="font-serif text-3xl font-bold text-foreground mb-12 text-center">
            Leadership Excellence
          </h3>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                icon: <Award className="w-8 h-8" />,
                title: "Expert Team",
                description: "Industry veterans with 20+ years of combined experience",
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: "Client-Centric",
                description: "Dedicated relationship managers for personalized service",
              },
              {
                icon: <Globe className="w-8 h-8" />,
                title: "Global Reach",
                description: "Access to international markets and opportunities",
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: "Innovation",
                description: "Cutting-edge technology and market insights",
              },
            ].map((item, idx) => (
              <div key={idx} className="card-luxury text-center">
                <div className="flex justify-center mb-4 text-accent">
                  {item.icon}
                </div>
                <h4 className="font-serif text-xl font-bold text-foreground mb-2">
                  {item.title}
                </h4>
                <p className="font-sans text-sm text-muted-foreground">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
