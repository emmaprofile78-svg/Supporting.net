import { useState, useMemo } from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Bar,
} from "recharts";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";

interface CalculatorData {
  month: number;
  contributions: number;
  gains: number;
  total: number;
  cumulativeContributions: number;
  realTotal?: number;
  realContributions?: number;
  realGains?: number;
}

export default function PortfolioCalculator() {
  const [initialInvestment, setInitialInvestment] = useState<number>(10000);
  const [monthlyContribution, setMonthlyContribution] = useState<number>(500);
  const [years, setYears] = useState<number>(20);
  const [annualReturn, setAnnualReturn] = useState<number>(8);
  const [inflationRate, setInflationRate] = useState<number>(2.5);
  const [accountForInflation, setAccountForInflation] = useState<boolean>(false);

  // Calculate portfolio projection with optional inflation adjustment
  const projectionData = useMemo(() => {
    const data: CalculatorData[] = [];
    let balance = initialInvestment;
    let cumulativeContributions = initialInvestment;
    const monthlyRate = annualReturn / 100 / 12;
    const monthlyInflationRate = inflationRate / 100 / 12;
    const totalMonths = years * 12;

    for (let month = 0; month <= totalMonths; month++) {
      const contributions = cumulativeContributions;
      const gains = balance - contributions;
      const total = balance;

      let dataPoint: CalculatorData = {
        month,
        contributions: Math.round(contributions),
        gains: Math.round(Math.max(0, gains)),
        total: Math.round(total),
        cumulativeContributions: Math.round(contributions),
      };

      // Calculate real purchasing power if inflation is enabled
      if (accountForInflation) {
        const inflationMultiplier = Math.pow(1 + monthlyInflationRate, month);
        dataPoint.realTotal = Math.round(total / inflationMultiplier);
        dataPoint.realContributions = Math.round(contributions / inflationMultiplier);
        dataPoint.realGains = Math.round(Math.max(0, gains / inflationMultiplier));
      }

      data.push(dataPoint);

      // Add monthly contribution and apply returns
      if (month < totalMonths) {
        balance += monthlyContribution;
        balance *= 1 + monthlyRate;
        cumulativeContributions += monthlyContribution;
      }
    }

    return data;
  }, [initialInvestment, monthlyContribution, years, annualReturn, inflationRate, accountForInflation]);

  const finalData = projectionData[projectionData.length - 1];
  const totalContributed = initialInvestment + monthlyContribution * years * 12;
  const totalGains = finalData ? finalData.total - totalContributed : 0;
  const roi = totalContributed > 0 ? (totalGains / totalContributed) * 100 : 0;

  // Real values accounting for inflation
  const realTotalValue = accountForInflation ? finalData?.realTotal || 0 : finalData?.total || 0;
  const realGains = accountForInflation ? finalData?.realGains || 0 : totalGains;
  const realRoi = totalContributed > 0 ? (realGains / totalContributed) * 100 : 0;

  // Sample data for display (every 6 months to reduce clutter)
  const displayData = projectionData.filter((_, idx) => idx % 6 === 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0]?.payload;
      
      // Handle growth chart (has month field)
      if (data.month !== undefined) {
        const year = Math.floor(data.month / 12);
        return (
          <div className="bg-card border border-border p-3 rounded shadow-lg">
            <p className="font-sans text-xs text-muted-foreground">
              Year {year}
            </p>
            <p className="font-sans text-sm font-semibold text-accent">
              {accountForInflation ? "Real " : ""}Total: ${(accountForInflation ? data.realTotal : data.total).toLocaleString()}
            </p>
            <p className="font-sans text-xs text-muted-foreground">
              Contributions: ${(accountForInflation ? data.realContributions : data.cumulativeContributions).toLocaleString()}
            </p>
            <p className="font-sans text-xs text-green-400">
              Gains: ${(accountForInflation ? data.realGains : data.gains).toLocaleString()}
            </p>
            {accountForInflation && (
              <p className="font-sans text-xs text-muted-foreground mt-2 border-t border-border pt-2">
                (Adjusted for {inflationRate.toFixed(1)}% inflation)
              </p>
            )}
          </div>
        );
      } else if (data.name !== undefined) {
        // Handle breakdown chart (has name field)
        const totalValue = data.contributions + data.gains;
        return (
          <div className="bg-card border border-border p-3 rounded shadow-lg">
            <p className="font-sans text-xs text-muted-foreground">
              Final Portfolio
            </p>
            <p className="font-sans text-xs text-muted-foreground">
              Contributions: ${data.contributions.toLocaleString()}
            </p>
            <p className="font-sans text-xs text-green-400">
              Gains: ${data.gains.toLocaleString()}
            </p>
            <p className="font-sans text-sm font-semibold text-accent mt-2 border-t border-border pt-2">
              Total: ${totalValue.toLocaleString()}
            </p>
            {accountForInflation && (
              <p className="font-sans text-xs text-muted-foreground mt-2">
                (Real value at {inflationRate.toFixed(1)}% inflation)
              </p>
            )}
          </div>
        );
      }
    }
    return null;
  };

  return (
    <section className="py-24 bg-background border-y border-border">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              Financial Planning
            </span>
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Portfolio Calculator
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl">
            Visualize your wealth growth with our interactive investment calculator. See how your initial investment and regular contributions compound over time.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Input Controls */}
          <div className="lg:col-span-1">
            <div className="card-luxury space-y-8">
              <div>
                <label className="font-sans text-sm font-semibold text-foreground block mb-3">
                  Initial Investment
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-accent font-serif text-lg">$</span>
                  <Input
                    type="number"
                    value={initialInvestment}
                    onChange={(e) =>
                      setInitialInvestment(Math.max(0, Number(e.target.value)))
                    }
                    className="bg-background border-border focus:border-accent focus:ring-accent"
                  />
                </div>
                <input
                  type="range"
                  min="0"
                  max="100000"
                  step="1000"
                  value={initialInvestment}
                  onChange={(e) => setInitialInvestment(Number(e.target.value))}
                  className="w-full mt-2 accent-accent"
                />
                <p className="font-sans text-xs text-muted-foreground mt-2">
                  Range: $0 - $100,000
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-accent to-transparent" />

              <div>
                <label className="font-sans text-sm font-semibold text-foreground block mb-3">
                  Monthly Contribution
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-accent font-serif text-lg">$</span>
                  <Input
                    type="number"
                    value={monthlyContribution}
                    onChange={(e) =>
                      setMonthlyContribution(Math.max(0, Number(e.target.value)))
                    }
                    className="bg-background border-border focus:border-accent focus:ring-accent"
                  />
                </div>
                <input
                  type="range"
                  min="0"
                  max="5000"
                  step="100"
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                  className="w-full mt-2 accent-accent"
                />
                <p className="font-sans text-xs text-muted-foreground mt-2">
                  Range: $0 - $5,000/month
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-accent to-transparent" />

              <div>
                <label className="font-sans text-sm font-semibold text-foreground block mb-3">
                  Investment Period
                </label>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-lg text-foreground">{years}</span>
                  <span className="font-sans text-sm text-muted-foreground">years</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="50"
                  step="1"
                  value={years}
                  onChange={(e) => setYears(Number(e.target.value))}
                  className="w-full mt-2 accent-accent"
                />
                <p className="font-sans text-xs text-muted-foreground mt-2">
                  Range: 1 - 50 years
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-accent to-transparent" />

              <div>
                <label className="font-sans text-sm font-semibold text-foreground block mb-3">
                  Expected Annual Return
                </label>
                <div className="flex items-center gap-2">
                  <span className="font-serif text-lg text-accent">{annualReturn.toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  step="0.5"
                  value={annualReturn}
                  onChange={(e) => setAnnualReturn(Number(e.target.value))}
                  className="w-full mt-2 accent-accent"
                />
                <p className="font-sans text-xs text-muted-foreground mt-2">
                  Range: 0% - 20% (Historical S&P 500: ~10%)
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-accent to-transparent" />

              {/* Inflation Toggle Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <label className="font-sans text-sm font-semibold text-foreground">
                    Account for Inflation
                  </label>
                  <Switch
                    checked={accountForInflation}
                    onCheckedChange={setAccountForInflation}
                  />
                </div>
                
                {accountForInflation && (
                  <div className="space-y-3 p-3 bg-card/50 border border-border">
                    <label className="font-sans text-xs font-semibold text-foreground block">
                      Inflation Rate: {inflationRate.toFixed(1)}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="10"
                      step="0.1"
                      value={inflationRate}
                      onChange={(e) => setInflationRate(Number(e.target.value))}
                      className="w-full accent-accent"
                    />
                    <p className="font-sans text-xs text-muted-foreground">
                      Range: 0% - 10% (Historical avg: ~2.5%)
                    </p>
                    <p className="font-sans text-xs text-accent mt-2">
                      Shows real purchasing power of your returns
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Charts and Results */}
          <div className="lg:col-span-2 space-y-8">
            {/* Growth Chart */}
            <div className="card-luxury">
              <h3 className="font-serif text-2xl font-bold text-foreground mb-6">
                Projected Portfolio Growth
                {accountForInflation && (
                  <span className="font-sans text-sm text-muted-foreground ml-2">
                    (Inflation-Adjusted)
                  </span>
                )}
              </h3>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={displayData}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#d4af37" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#d4af37" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorContributions" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#666" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#666" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                  <XAxis
                    dataKey="month"
                    stroke="#666"
                    tickFormatter={(value) => `Year ${Math.floor(value / 12)}`}
                  />
                  <YAxis stroke="#666" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey={accountForInflation ? "realContributions" : "cumulativeContributions"}
                    stackId="1"
                    stroke="#666"
                    fill="url(#colorContributions)"
                    name="Your Contributions"
                  />
                  <Area
                    type="monotone"
                    dataKey={accountForInflation ? "realGains" : "gains"}
                    stackId="1"
                    stroke="#d4af37"
                    fill="url(#colorTotal)"
                    name="Investment Gains"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Breakdown Chart */}
            <div className="card-luxury">
              <h3 className="font-serif text-2xl font-bold text-foreground mb-6">
                Final Portfolio Breakdown
                {accountForInflation && (
                  <span className="font-sans text-sm text-muted-foreground ml-2">
                    (Real Value)
                  </span>
                )}
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <ComposedChart
                  data={[
                    {
                      name: "Breakdown",
                      contributions: accountForInflation 
                        ? finalData?.realContributions || 0 
                        : finalData?.cumulativeContributions || 0,
                      gains: accountForInflation 
                        ? finalData?.realGains || 0 
                        : finalData?.gains || 0,
                    },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                  <XAxis dataKey="name" stroke="#666" />
                  <YAxis stroke="#666" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar
                    dataKey="contributions"
                    fill="#666"
                    name="Your Contributions"
                  />
                  <Bar dataKey="gains" fill="#d4af37" name="Investment Gains" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <div className="card-luxury text-center">
            <p className="font-sans text-sm text-muted-foreground mb-2">
              Total Contributions
            </p>
            <p className="font-serif text-3xl font-bold text-foreground">
              ${totalContributed.toLocaleString()}
            </p>
          </div>
          <div className="card-luxury text-center">
            <p className="font-sans text-sm text-muted-foreground mb-2">
              Investment Gains
            </p>
            <p className="font-serif text-3xl font-bold text-green-400">
              ${(accountForInflation ? realGains : totalGains).toLocaleString()}
            </p>
            {accountForInflation && (
              <p className="font-sans text-xs text-muted-foreground mt-1">
                (Real value)
              </p>
            )}
          </div>
          <div className="card-luxury text-center">
            <p className="font-sans text-sm text-muted-foreground mb-2">
              Final Portfolio Value
            </p>
            <p className="font-serif text-3xl font-bold text-accent">
              ${realTotalValue.toLocaleString()}
            </p>
            {accountForInflation && (
              <p className="font-sans text-xs text-muted-foreground mt-1">
                (Real value)
              </p>
            )}
          </div>
          <div className="card-luxury text-center">
            <p className="font-sans text-sm text-muted-foreground mb-2">
              Return on Investment
            </p>
            <p className="font-serif text-3xl font-bold text-accent">
              {(accountForInflation ? realRoi : roi).toFixed(1)}%
            </p>
            {accountForInflation && (
              <p className="font-sans text-xs text-muted-foreground mt-1">
                (Real return)
              </p>
            )}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 p-6 border border-border bg-card/50 rounded-none">
          <p className="font-sans text-xs text-muted-foreground">
            <strong>Disclaimer:</strong> This calculator provides estimates based on the inputs you provide. Actual investment returns may vary significantly based on market conditions, asset allocation, fees, taxes, and other factors. Past performance does not guarantee future results. Please consult with a financial advisor before making investment decisions.
          </p>
        </div>
      </div>
    </section>
  );
}
