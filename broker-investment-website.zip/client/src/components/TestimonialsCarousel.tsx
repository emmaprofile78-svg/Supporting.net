import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Testimonial {
  quote: string;
  author: string;
  title: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    quote:
      "Apex Capital transformed my investment strategy. Their institutional-grade tools and personalized guidance have consistently delivered exceptional returns.",
    author: "Margaret Chen",
    title: "CEO, Tech Ventures Inc.",
    rating: 5,
  },
  {
    quote:
      "The platform's sophistication combined with ease of use is unmatched. I've managed my portfolio more effectively than ever before.",
    author: "James Richardson",
    title: "Portfolio Manager",
    rating: 5,
  },
  {
    quote:
      "Outstanding customer service and market insights. Apex Capital truly understands the needs of serious investors.",
    author: "Victoria Ashford",
    title: "Independent Investor",
    rating: 5,
  },
  {
    quote:
      "The real-time analytics and comprehensive market data have given me a competitive edge. Highly recommended for any serious trader.",
    author: "David Park",
    title: "Hedge Fund Director",
    rating: 5,
  },
  {
    quote:
      "Professional, reliable, and innovative. Apex Capital is the partner I trust with my financial future.",
    author: "Elena Rodriguez",
    title: "Wealth Manager",
    rating: 5,
  },
];

export default function TestimonialsCarousel() {
  const [current, setCurrent] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  useEffect(() => {
    if (!autoPlay) return;

    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [autoPlay]);

  const next = () => {
    setCurrent((prev) => (prev + 1) % testimonials.length);
    setAutoPlay(false);
  };

  const prev = () => {
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    setAutoPlay(false);
  };

  const testimonial = testimonials[current];

  return (
    <section className="py-24 bg-card border-y border-border">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 text-center space-y-4">
          <div className="flex items-center justify-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              Client Testimonials
            </span>
            <div className="w-12 h-px bg-accent" />
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Trusted by Industry Leaders
          </h2>
        </div>

        {/* Carousel */}
        <div className="max-w-4xl mx-auto">
          {/* Testimonial Card */}
          <div className="card-luxury relative min-h-96 flex flex-col justify-between">
            {/* Decorative quote mark */}
            <div className="absolute top-6 left-6 text-6xl text-accent opacity-20 font-serif">
              "
            </div>

            {/* Quote */}
            <div className="relative z-10 space-y-8">
              <p className="font-sans text-xl text-foreground leading-relaxed italic">
                "{testimonial.quote}"
              </p>

              {/* Star Rating */}
              <div className="flex gap-1">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-accent text-accent"
                  />
                ))}
              </div>
            </div>

            {/* Author Info */}
            <div className="space-y-2 pt-8 border-t border-border">
              <p className="font-serif text-lg font-bold text-foreground">
                {testimonial.author}
              </p>
              <p className="font-sans text-sm text-muted-foreground">
                {testimonial.title}
              </p>
            </div>

            {/* Decorative corner */}
            <div className="absolute bottom-6 right-6 w-8 h-8 border-b-2 border-r-2 border-accent opacity-30" />
          </div>

          {/* Navigation */}
          <div className="mt-12 flex items-center justify-between">
            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setCurrent(idx);
                    setAutoPlay(false);
                  }}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    idx === current ? "bg-accent w-8" : "bg-border hover:bg-muted"
                  }`}
                />
              ))}
            </div>

            {/* Arrow Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={prev}
                variant="outline"
                size="icon"
                className="border-border hover:border-accent hover:text-accent"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button
                onClick={next}
                variant="outline"
                size="icon"
                className="border-border hover:border-accent hover:text-accent"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Testimonial Counter */}
          <div className="mt-8 text-center">
            <p className="font-sans text-sm text-muted-foreground">
              <span className="font-bold text-accent">{current + 1}</span> / {testimonials.length}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
