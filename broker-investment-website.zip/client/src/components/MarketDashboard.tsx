import {
  LineChart,
  Line,
  AreaChart,
  Area,
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

// Mock data for portfolio performance
const portfolioData = [
  { month: "Jan", value: 100000, benchmark: 100000 },
  { month: "Feb", value: 112000, benchmark: 103000 },
  { month: "Mar", value: 108000, benchmark: 105000 },
  { month: "Apr", value: 125000, benchmark: 110000 },
  { month: "May", value: 135000, benchmark: 115000 },
  { month: "Jun", value: 142000, benchmark: 118000 },
  { month: "Jul", value: 155000, benchmark: 122000 },
  { month: "Aug", value: 148000, benchmark: 120000 },
  { month: "Sep", value: 165000, benchmark: 125000 },
  { month: "Oct", value: 178000, benchmark: 130000 },
  { month: "Nov", value: 185000, benchmark: 133000 },
  { month: "Dec", value: 198000, benchmark: 137000 },
];

// Mock data for asset allocation
const assetAllocationData = [
  { category: "Stocks", value: 45, allocation: 45 },
  { category: "Crypto", value: 25, allocation: 25 },
  { category: "Forex", value: 15, allocation: 15 },
  { category: "ETFs", value: 15, allocation: 15 },
];

// Mock data for price performance
const priceData = [
  { time: "9:00", AAPL: 189, GOOGL: 142, MSFT: 416, TSLA: 245 },
  { time: "10:00", AAPL: 191, GOOGL: 141, MSFT: 418, TSLA: 243 },
  { time: "11:00", AAPL: 188, GOOGL: 143, MSFT: 415, TSLA: 248 },
  { time: "12:00", AAPL: 192, GOOGL: 142, MSFT: 420, TSLA: 246 },
  { time: "13:00", AAPL: 190, GOOGL: 144, MSFT: 417, TSLA: 250 },
  { time: "14:00", AAPL: 193, GOOGL: 141, MSFT: 422, TSLA: 244 },
  { time: "15:00", AAPL: 189, GOOGL: 145, MSFT: 419, TSLA: 252 },
  { time: "16:00", AAPL: 195, GOOGL: 142, MSFT: 425, TSLA: 248 },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border p-3 rounded shadow-lg">
        <p className="font-sans text-xs text-muted-foreground">
          {payload[0]?.payload?.month || payload[0]?.payload?.time}
        </p>
        {payload.map((entry: any, idx: number) => (
          <p key={idx} style={{ color: entry.color }} className="font-sans text-sm font-semibold">
            {entry.name}: ${entry.value.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function MarketDashboard() {
  return (
    <section id="markets" className="py-24 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-px bg-accent" />
            <span className="font-sans text-xs font-bold text-accent uppercase tracking-widest">
              Market Intelligence
            </span>
          </div>
          <h2 className="font-serif text-5xl md:text-6xl font-bold text-foreground">
            Portfolio Dashboard
          </h2>
          <p className="font-sans text-lg text-muted-foreground max-w-2xl">
            Real-time market data and portfolio performance analytics powered by advanced charting.
          </p>
        </div>

        {/* Charts Grid */}
        <div className="space-y-12">
          {/* Portfolio Performance Chart */}
          <div className="card-luxury">
            <h3 className="font-serif text-2xl font-bold text-foreground mb-6">
              Portfolio Performance
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={portfolioData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d4af37" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#d4af37" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis dataKey="month" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#d4af37"
                  fillOpacity={1}
                  fill="url(#colorValue)"
                  name="Portfolio Value"
                />
                <Area
                  type="monotone"
                  dataKey="benchmark"
                  stroke="#666"
                  fillOpacity={0}
                  name="Benchmark"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Multi-Asset Price Comparison */}
          <div className="card-luxury">
            <h3 className="font-serif text-2xl font-bold text-foreground mb-6">
              Asset Price Trends
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={priceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis dataKey="time" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="AAPL"
                  stroke="#d4af37"
                  strokeWidth={2}
                  dot={false}
                  name="AAPL"
                />
                <Line
                  type="monotone"
                  dataKey="GOOGL"
                  stroke="#60a5fa"
                  strokeWidth={2}
                  dot={false}
                  name="GOOGL"
                />
                <Line
                  type="monotone"
                  dataKey="MSFT"
                  stroke="#34d399"
                  strokeWidth={2}
                  dot={false}
                  name="MSFT"
                />
                <Line
                  type="monotone"
                  dataKey="TSLA"
                  stroke="#f87171"
                  strokeWidth={2}
                  dot={false}
                  name="TSLA"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Asset Allocation Comparison */}
          <div className="card-luxury">
            <h3 className="font-serif text-2xl font-bold text-foreground mb-6">
              Asset Allocation
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <ComposedChart data={assetAllocationData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis dataKey="category" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="allocation" fill="#d4af37" name="Allocation %" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="mt-16 grid md:grid-cols-4 gap-6">
          {[
            { label: "Total Return", value: "+98.0%", color: "text-green-400" },
            { label: "YTD Performance", value: "+24.5%", color: "text-green-400" },
            { label: "Volatility", value: "12.3%", color: "text-yellow-400" },
            { label: "Sharpe Ratio", value: "1.85", color: "text-accent" },
          ].map((metric, idx) => (
            <div key={idx} className="card-luxury text-center">
              <p className="font-sans text-sm text-muted-foreground mb-2">{metric.label}</p>
              <p className={`font-serif text-3xl font-bold ${metric.color}`}>{metric.value}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
