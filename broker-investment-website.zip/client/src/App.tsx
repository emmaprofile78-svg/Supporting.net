import { useRef } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Navigation from "./components/Navigation";
import HeroSection from "./components/HeroSection";
import MarketTicker from "./components/MarketTicker";
import ServicesSection from "./components/ServicesSection";
import MarketDashboard from "./components/MarketDashboard";
import TestimonialsCarousel from "./components/TestimonialsCarousel";
import AboutSection from "./components/AboutSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import NotFound from "./pages/NotFound";
import PortfolioCalculator from "./components/PortfolioCalculator";

function HomePage() {
  const contactRef = useRef<HTMLDivElement>(null);

  const handleGetStarted = () => {
    const contactSection = document.getElementById("contact");
    contactSection?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation onContactClick={handleGetStarted} />
      <MarketTicker />
      <HeroSection onGetStarted={handleGetStarted} onLearnMore={() => {
        const servicesSection = document.getElementById("services");
        servicesSection?.scrollIntoView({ behavior: "smooth" });
      }} />
      <ServicesSection />
      <MarketDashboard />
      <TestimonialsCarousel />
      <AboutSection />
      <PortfolioCalculator />
      <div ref={contactRef}>
        <ContactSection />
      </div>
      <Footer />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={HomePage} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
